const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DB_FILE = path.join(__dirname, 'posts.json');

// Make sure the uploads folder and posts.json file exist
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, '[]');

// ---- Simple flat-file "database" helpers ----
function readPosts() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    return [];
  }
}

function writePosts(posts) {
  fs.writeFileSync(DB_FILE, JSON.stringify(posts, null, 2));
}

// ---- Multer setup (handles the actual file upload) ----
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const MAX_SIZE = 15 * 1024 * 1024; // 15MB — raise/lower as you like

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname).toLowerCase());
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only jpg, png, gif, and webp images are allowed'));
    }
  }
});

app.use(express.static(path.join(__dirname, 'public'))); // serves index.html
app.use('/uploads', express.static(UPLOAD_DIR));          // serves the images

// ---- API routes ----

// Get every post — this is what makes it show up for everyone, on every device
app.get('/api/posts', (req, res) => {
  res.json(readPosts());
});

// Upload a new post
app.post('/api/upload', (req, res) => {
  upload.single('image')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No image received.' });
    }

    const posts = readPosts();
    const newPost = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      filename: req.file.filename,
      caption: (req.body.caption || '').slice(0, 500), // basic length guard
      timestamp: new Date().toISOString()
    };
    posts.unshift(newPost); // newest first
    writePosts(posts);

    res.json(newPost);
  });
});

app.listen(PORT, () => {
  console.log(`Imageboard running at http://localhost:${PORT}`);
});
